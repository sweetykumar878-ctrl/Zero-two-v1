package com.zerotwo.companion.domain

import kotlinx.coroutines.flow.StateFlow

enum class ConversationState { Idle, Connecting, Listening, Thinking, Speaking, Error, Offline }
enum class CompanionMode { AUTO, ONLINE_ONLY, OFFLINE_ONLY }

interface ConversationEngine {
    val state: StateFlow<ConversationState>
    val lastTranscript: StateFlow<String>
    val lastResponse: StateFlow<String>
    suspend fun startSession()
    suspend fun stopSession()
    suspend fun processUserText(text: String, detectedMood: String = "neutral"): String
    suspend fun interrupt()
}

interface SpeechRecognizer {
    val isListening: StateFlow<Boolean>
    suspend fun startListening(onPartial: (String) -> Unit, onFinal: (String) -> Unit)
    suspend fun stopListening()
}

interface SpeechSynthesizer {
    val isSpeaking: StateFlow<Boolean>
    suspend fun speak(text: String, onComplete: () -> Unit = {})
    suspend fun stop()
    suspend fun setVoice(voiceId: String)
}

interface WakeWordEngine {
    val isRunning: StateFlow<Boolean>
    suspend fun startListening(onWakeDetected: (String) -> Unit)
    suspend fun stopListening()
}

interface VoiceProvider {
    fun getAvailableVoices(): List<VoiceItem>
    fun getSelectedVoice(): VoiceItem
    suspend fun setSelectedVoice(voiceId: String)
}

data class VoiceItem(val id: String, val displayName: String, val gender: String, val description: String, val isOnlineOnly: Boolean = false)

interface MemoryManager {
    suspend fun savePreference(key: String, value: String)
    suspend fun getPreference(key: String, defaultValue: String): String
    suspend fun saveUserVoiceProfile(samplePcm: ByteArray)
    suspend fun hasVoiceProfile(): Boolean
}

interface AvatarRenderer {
    fun renderState(state: ConversationState)
    fun triggerExpression(mood: String)
}

interface DeviceController {
    suspend fun setVolume(level: Int)
    suspend fun getBatteryLevel(): Int
}

interface WebSearchTool {
    suspend fun search(query: String): String
}