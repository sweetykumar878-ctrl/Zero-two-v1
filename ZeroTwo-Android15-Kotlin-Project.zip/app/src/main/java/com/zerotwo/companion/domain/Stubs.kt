package com.zerotwo.companion.domain

/**
 * ARCHITECTURAL STUBS FOR FUTURE EXPANSION.
 * Strictly marked: "Not implemented in V1."
 */
class Live2DAvatarStub : AvatarRenderer {
    override fun renderState(state: ConversationState) { /* Not implemented in V1 */ }
    override fun triggerExpression(mood: String) { /* Not implemented in V1 */ }
}

interface EmotionDetector {
    fun detectEmotionFromAudio(audioChunk: ShortArray): String = "neutral (Not implemented in V1)"
}

class AndroidDeviceControllerStub : DeviceController {
    override suspend fun setVolume(level: Int) { /* Not implemented in V1 */ }
    override suspend fun getBatteryLevel(): Int = 100
}

class WebSearchToolStub : WebSearchTool {
    override suspend fun search(query: String): String = "Not implemented in V1."
}