package com.zerotwo.companion.wakeword

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import com.zerotwo.companion.domain.WakeWordEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

class WakeWordEngineImpl(
    private val context: Context,
    private val modelDirectory: File
) : WakeWordEngine {

    companion object {
        private const val TAG = "WakeWordEngine"
        private const val SAMPLE_RATE = 16000
        private const val GRAMMAR_JSON = "["wake up zero two", "wake up zero tu", "zero two", "[unk]"]"
    }

    private val _isRunning = MutableStateFlow(false)
    override val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private var voskModel: Model? = null
    private var recognizer: Recognizer? = null
    private var audioRecord: AudioRecord? = null

    init {
        try {
            if (modelDirectory.exists()) {
                voskModel = Model(modelDirectory.absolutePath)
                recognizer = Recognizer(voskModel, SAMPLE_RATE.toFloat(), GRAMMAR_JSON)
                Log.d(TAG, "Vosk wake-word loaded with grammar: $GRAMMAR_JSON")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Vosk model: ${e.message}")
        }
    }

    override suspend fun startListening(onWakeDetected: (String) -> Unit) = withContext(Dispatchers.IO) {
        if (_isRunning.value) return@withContext
        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)

        try {
            audioRecord = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBufferSize, 4096))
            audioRecord?.startRecording()
            _isRunning.value = true

            val buffer = ByteArray(2048)
            while (isActive && _isRunning.value) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                if (read > 0) {
                    val rec = recognizer
                    if (rec != null) {
                        if (rec.acceptWaveForm(buffer, read)) {
                            val text = JSONObject(rec.result).optString("text", "").lowercase()
                            if (text.contains("wake up zero two") || text.contains("wake up zero tu")) {
                                withContext(Dispatchers.Main) { onWakeDetected(text) }
                                rec.reset()
                            }
                        }
                    }
                }
            }
        } finally {
            stopListening()
        }
    }

    override suspend fun stopListening() {
        _isRunning.value = false
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }
}