package com.zerotwo.companion.ai

import android.content.Context
import android.util.Base64
import android.util.Log
import com.zerotwo.companion.audio.AudioRecordManager
import com.zerotwo.companion.audio.AudioTrackPlayer
import com.zerotwo.companion.domain.ConversationEngine
import com.zerotwo.companion.domain.ConversationState
import com.zerotwo.companion.security.SecureConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Native Android client for Google Gemini Live Multimodal WebSocket API.
 * Uses official model 'gemini-3.8-live' with bidirectional 16kHz audio input and 24kHz audio output.
 */
class GeminiLiveEngine(
    private val context: Context,
    private val scope: CoroutineScope
) : ConversationEngine {

    companion object {
        private const val TAG = "GeminiLiveEngine"
        const val LIVE_MODEL = "gemini-3.8-live"
        private const val LIVE_ENDPOINT_HOST = "generativelanguage.googleapis.com"
    }

    private val _state = MutableStateFlow(ConversationState.Idle)
    override val state: StateFlow<ConversationState> = _state.asStateFlow()

    private val _lastTranscript = MutableStateFlow("")
    override val lastTranscript: StateFlow<String> = _lastTranscript.asStateFlow()

    private val _lastResponse = MutableStateFlow("")
    override val lastResponse: StateFlow<String> = _lastResponse.asStateFlow()

    private val okHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var audioRecordManager: AudioRecordManager? = null
    private var audioTrackPlayer: AudioTrackPlayer? = null
    private var recordingJob: Job? = null
    private var activeVoiceName: String = "Kore"

    fun setVoice(voiceName: String) {
        this.activeVoiceName = voiceName
    }

    override suspend fun startSession() = withContext(Dispatchers.IO) {
        if (_state.value == ConversationState.Connecting || _state.value == ConversationState.Listening) {
            return@withContext
        }

        val apiKey = SecureConfig.getApiKey(context)
        if (apiKey.isBlank()) {
            _state.value = ConversationState.Error
            _lastResponse.value = "Gemini API key is not configured. Please check Settings."
            return@withContext
        }

        _state.value = ConversationState.Connecting
        audioTrackPlayer = AudioTrackPlayer()
        audioRecordManager = AudioRecordManager(context)

        val wsUrl = "wss://$LIVE_ENDPOINT_HOST/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder()
            .url(wsUrl)
            .addHeader("User-Agent", "aistudio-build-android")
            .build()

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "Gemini Live WebSocket opened successfully.")
                sendInitialSetupMessage(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}", t)
                _state.value = ConversationState.Error
                _lastResponse.value = "Connection lost: ${t.localizedMessage ?: "Unknown error"}"
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closed: $code $reason")
                _state.value = ConversationState.Idle
            }
        })
    }

    private fun sendInitialSetupMessage(ws: WebSocket) {
        try {
            val setupJson = JSONObject().apply {
                put("setup", JSONObject().apply {
                    put("model", "models/$LIVE_MODEL")
                    put("generationConfig", JSONObject().apply {
                        put("responseModalities", JSONArray().apply { put("AUDIO") })
                        put("speechConfig", JSONObject().apply {
                            put("voiceConfig", JSONObject().apply {
                                put("prebuiltVoiceConfig", JSONObject().apply {
                                    put("voiceName", activeVoiceName)
                                })
                            })
                        })
                    })
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", PersonaConfig.SYSTEM_PROMPT)
                            })
                        })
                    })
                })
            }
            ws.send(setupJson.toString())
            _state.value = ConversationState.Listening
            startMicrophoneStream()
        } catch (e: Exception) {
            Log.e(TAG, "Error sending setup message: ${e.message}", e)
            _state.value = ConversationState.Error
        }
    }

    private fun startMicrophoneStream() {
        recordingJob?.cancel()
        recordingJob = scope.launch(Dispatchers.IO) {
            audioRecordManager?.startRecording { pcmChunk ->
                sendAudioInputChunk(pcmChunk)
            }
        }
    }

    private fun sendAudioInputChunk(pcmChunk: ByteArray) {
        val ws = webSocket ?: return
        try {
            val base64Data = Base64.encodeToString(pcmChunk, Base64.NO_WRAP)
            val realtimeInputJson = JSONObject().apply {
                put("realtimeInput", JSONObject().apply {
                    put("mediaChunks", JSONArray().apply {
                        put(JSONObject().apply {
                            put("mimeType", "audio/pcm;rate=16000")
                            put("data", base64Data)
                        })
                    })
                })
            }
            ws.send(realtimeInputJson.toString())
        } catch (e: Exception) {
            Log.w(TAG, "Error streaming audio chunk: ${e.message}")
        }
    }

    private fun handleServerMessage(jsonText: String) {
        try {
            val json = JSONObject(jsonText)
            val serverContent = json.optJSONObject("serverContent") ?: return

            if (serverContent.optBoolean("interrupted", false)) {
                Log.d(TAG, "Server recognized user barge-in! Interrupting playback.")
                audioTrackPlayer?.interrupt()
                _state.value = ConversationState.Listening
                return
            }

            val modelTurn = serverContent.optJSONObject("modelTurn")
            if (modelTurn != null) {
                val parts = modelTurn.optJSONArray("parts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val inlineData = part.optJSONObject("inlineData")
                        if (inlineData != null) {
                            val base64Audio = inlineData.optString("data", "")
                            if (base64Audio.isNotEmpty()) {
                                val audioBytes = Base64.decode(base64Audio, Base64.NO_WRAP)
                                audioTrackPlayer?.enqueueChunk(audioBytes)
                                _state.value = ConversationState.Speaking
                            }
                        }
                        val text = part.optString("text", "")
                        if (text.isNotEmpty()) {
                            _lastResponse.value = text
                        }
                    }
                }
            }

            if (serverContent.optBoolean("turnComplete", false)) {
                if (_state.value != ConversationState.Error) {
                    _state.value = ConversationState.Listening
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing server message: ${e.message}", e)
        }
    }

    override suspend fun processUserText(text: String, detectedMood: String): String {
        _lastTranscript.value = text
        _state.value = ConversationState.Thinking
        val ws = webSocket
        if (ws != null) {
            val clientContentJson = JSONObject().apply {
                put("clientContent", JSONObject().apply {
                    put("turns", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", "[Mood: $detectedMood] $text")
                                })
                            })
                        })
                    })
                    put("turnComplete", true)
                })
            }
            ws.send(clientContentJson.toString())
        }
        return "Sending text to Gemini Live..."
    }

    override suspend fun interrupt() {
        audioTrackPlayer?.interrupt()
        _state.value = ConversationState.Listening
    }

    override suspend fun stopSession() = withContext(Dispatchers.IO) {
        recordingJob?.cancel()
        recordingJob = null
        audioRecordManager?.stopRecording()
        audioRecordManager = null
        audioTrackPlayer?.release()
        audioTrackPlayer = null
        try {
            webSocket?.close(1000, "User ended session")
        } catch (e: Exception) {
            Log.w(TAG, "Error closing websocket: ${e.message}")
        }
        webSocket = null
        _state.value = ConversationState.Idle
    }
}