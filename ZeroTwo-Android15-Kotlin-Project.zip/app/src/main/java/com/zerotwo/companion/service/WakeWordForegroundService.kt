package com.zerotwo.companion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.zerotwo.companion.overlay.FloatingCompanionOverlayService
import com.zerotwo.companion.ui.MainActivity
import com.zerotwo.companion.wakeword.WakeWordEngineImpl
import kotlinx.coroutines.*
import java.io.File

/**
 * Android 15 compliant Foreground Service for Wake-Word Listening.
 * Declares FOREGROUND_SERVICE_TYPE_MICROPHONE as required by Android 14 & 15.
 */
class WakeWordForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "zero_two_wakeword_channel"
        const val NOTIFICATION_ID = 2002
        const val ACTION_STOP_LISTENING = "com.zerotwo.companion.STOP_LISTENING"
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var wakeWordEngine: WakeWordEngineImpl? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val modelDir = File(filesDir, "offline_models/vosk-model-small-en-in-0.4")
        wakeWordEngine = WakeWordEngineImpl(this, modelDir)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_LISTENING) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundWithNotification()
        serviceScope.launch {
            wakeWordEngine?.startListening {
                val overlayIntent = Intent(this@WakeWordForegroundService, FloatingCompanionOverlayService::class.java)
                startService(overlayIntent)
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val stopIntent = Intent(this, WakeWordForegroundService::class.java).apply { action = ACTION_STOP_LISTENING }
        val stopPending = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Zero Two is listening for the wake phrase")
            .setContentText("Say \"Wake up Zero Two\" to open companion")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Listening", stopPending)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Zero Two Listening", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        wakeWordEngine = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}